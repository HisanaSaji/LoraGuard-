class EnvConfig {
  static const String openWeatherApiKey = '439232114d306753375f733d8d868977';
  
  // Add other environment variables here
} 